import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'change-email',
  templateUrl: './change-email.component.html',
  styleUrls: ['./change-email.component.css']
})
export class ChangeEmailComponent implements OnInit {

  public emailFormGroup: FormGroup;
  isDisabled: boolean = true;

  constructor() {
    this.emailFormGroup = new FormGroup({
      newEmail: new FormControl('example@mail.mil', [Validators.required, Validators.email, Validators.minLength(2), Validators.maxLength(40)]),
      confirmEmail: new FormControl('example@mail.mil', [Validators.required, Validators.email, Validators.minLength(2), Validators.maxLength(40)])
    },);
  }

  ngOnInit(): void {
  }

  public checkError = (controlName: string, errorName: string) => {
    return this.emailFormGroup.controls[controlName].hasError(errorName);
  }

  setIsDisabled(disabled: boolean){
    this.isDisabled = disabled;
  }
  
  onSubmit() { }

  onCancel() { }

  onReset() {
    this.emailFormGroup.controls.newEmail.setValue('');
    this.emailFormGroup.controls.confirmEmail.setValue('');

    this.emailFormGroup.clearValidators();
    this.setIsDisabled(true);
  }
}
