import { Component } from '@angular/core';
import { MatToolbarModule } from "@angular/material/toolbar";
import { Router } from '@angular/router';

@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

  title = 'angular-material-tab-router';  
  navLinks: any[];
  activeLinkIndex = -1; 
  constructor(private router: Router) {
    this.navLinks = [
      {
        label: 'Home',
        link: './home',
        index: 0
      }, {
        label: 'Buttons',
        link: './button-page',
        index: 1
      }, {
        label: 'Selectors',
        link: './selectors',
        index: 2
      }, {
        label: 'Input Fields',
        link: './input-fields',
        index: 3
      }, {
        label: 'Controls',
        link: './controls',
        index: 4
      }, {
        label: 'Stepper',
        link: './stepper',
        index: 5
      }, {
        label: 'Applicant',
        link: './applicant',
        index: 6
      }, {
        label: 'Change Email',
        link: './change-email',
        index: 7
      }, 
    ];
  }

  ngOnInit(): void {
    this.router.events.subscribe((res) => {
        this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));
    });
  }
}
