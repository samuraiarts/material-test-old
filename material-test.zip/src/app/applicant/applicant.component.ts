import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
